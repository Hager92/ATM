#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "DIO.h"
#include "CLCD.h"
#include <avr/io.h>
#include <util/delay.h>
#include "Keypad.h"

void main(void) {
	DIO_SetPortDirection(CLCD_DATA_PORT, DIO_PORT_OUTPUT);
	DIO_SetPinDirection(CLCD_CTRL_PORT, DIO_PIN0, DIO_OUTPUT);
	DIO_SetPinDirection(CLCD_CTRL_PORT, DIO_PIN1, DIO_OUTPUT);
	DIO_SetPinDirection(CLCD_CTRL_PORT, DIO_PIN2, DIO_OUTPUT);

	CLCD_voidInitl();
	CLCD_voidSrting("Welcome,Enter");
	CLCD_voidGoTo_X_Y(1, 0);
	CLCD_voidSrting("your password");
	_delay_ms(1000);

	u8 x;
	u16 balance = 5000;

	KPD_Init();
	CLCD_voidInitl();
	char enteredPassword[6]; // To store the entered password
	char correctPassword[6] = "12345"; // Correct password as a string
	u8 y;
	int h = 3;
	// enter the password and check validation
	while (1) {
		if (h == 0) {
			CLCD_voidGoTo_X_Y(0, 0);
			CLCD_voidSrting("Max trials reached");
			CLCD_voidGoTo_X_Y(1, 0);
			CLCD_voidSrting("Access blocked");
			break;
		}

		do {
			y = KPD_GETPressedKey();
		} while (y == KPD_NOT_PRESSED_KEY);

		if (y == '=') {
			CLCD_voidLCD_Clear();

			int isPasswordCorrect = 1;
			for (int i = 0; i < 5; i++) {
				if (enteredPassword[i] != correctPassword[i]) {
					isPasswordCorrect = 0;
					break;
				}
			}

			CLCD_voidGoTo_X_Y(1, 0); // Display "Correct" or "Wrong"
			if (isPasswordCorrect) {
				CLCD_voidSrting("Correct");
				_delay_ms(1000);
				break; // Exit the password input loop
			} else {
				h--;
				CLCD_voidSrting("Wrong");
				CLCD_voidGoTo_X_Y(2, 0);
				CLCD_voidSrting("Trials left:");
				CLCD_voidSendData(h + '0');
				_delay_ms(1000);
				CLCD_voidLCD_Clear();
				memset(enteredPassword, 0, sizeof(enteredPassword)); // Reset entered password
			}
		} else {
			// Accumulate the entered digits as a string
			if (y >= '0' && y <= '9') {
				for (int i = 0; i < 5; i++) {
					if (enteredPassword[i] == '\0') {
						enteredPassword[i] = y;
						break;
					}
				}
			}

			// Display the entered digits on the LCD
			CLCD_voidGoTo_X_Y(0, 0);
			CLCD_voidSrting(enteredPassword);
		}
	}

	// menu of options
	if (h > 0) {
		CLCD_voidLCD_Clear();
		CLCD_voidSrting("(1)Show balance..");
		_delay_ms(500);
		CLCD_voidLCD_Clear();
		CLCD_voidSrting("(2)Insert money..");
		_delay_ms(500);
		CLCD_voidLCD_Clear();
		CLCD_voidSrting("(3)Withdraw..");
		_delay_ms(500);
		CLCD_voidLCD_Clear();

		while (1) {
			do {
				x = KPD_GETPressedKey();
			} while (x == KPD_NOT_PRESSED_KEY);

			CLCD_voidLCD_Clear();
			CLCD_voidSendData(x);

			if (x == '1') {
				// Show balance
				CLCD_voidLCD_Clear();
				CLCD_voidGoTo_X_Y(0, 0);
				CLCD_voidSrting("balance");
				CLCD_voidGoTo_X_Y(1, 0);
				CLCD_voidPrintNUM(balance); // Print the balance
				_delay_ms(1000);
				CLCD_voidLCD_Clear();
			} else if (x == '2') {
				// Insert money
				CLCD_voidLCD_Clear();
				CLCD_voidSrting("Enter amount");
				_delay_ms(1000);
				CLCD_voidLCD_Clear();

				u16 money = 0;
				u8 k;
				while (1) {
					do {
						k = KPD_GETPressedKey();
					} while (k == KPD_NOT_PRESSED_KEY);

					if (k == '=') {
						break;
					}

					// take the money from the user
					money = money * 10 + (k - '0');

					// Display the entered digits on the LCD
					CLCD_voidGoTo_X_Y(0, 0);
					CLCD_voidPrintNUM(money);
				}

				// Update the balance
				balance += money;
				CLCD_voidGoTo_X_Y(0, 0);
				CLCD_voidSrting("Updated balance");
				CLCD_voidGoTo_X_Y(1, 0);
				CLCD_voidPrintNUM(balance); // Print the new balance
				_delay_ms(1000);
				CLCD_voidLCD_Clear();
			} else if (x == '3') {
				// Withdraw money
				CLCD_voidLCD_Clear();
				CLCD_voidGoTo_X_Y(0, 0);
				CLCD_voidSrting("Enter amount"); // Assuming user enters a valid amount
				_delay_ms(1000);
				CLCD_voidLCD_Clear();

				u16 money = 0;
				u8 k;
				while (1) {
					do {
						k = KPD_GETPressedKey();
					} while (k == KPD_NOT_PRESSED_KEY);

					if (k == '=') {
						break;
					}

					// take the money from the user
					money = money * 10 + (k - '0');

					// Display the entered digits on the LCD
					CLCD_voidGoTo_X_Y(0, 0);
					CLCD_voidPrintNUM(money);
				}

				if (money <= balance) {
					// Update the balance
					balance -= money;
					CLCD_voidGoTo_X_Y(0, 0);
					CLCD_voidSrting("Updated balance");
					CLCD_voidGoTo_X_Y(1, 0);
					CLCD_voidPrintNUM(balance);
					_delay_ms(1000);
					CLCD_voidLCD_Clear();
				} else {
					CLCD_voidGoTo_X_Y(0, 0);
					CLCD_voidSrting("Invalid balance!"); // amount of money larger than balance
					_delay_ms(1000);
					CLCD_voidLCD_Clear();
				}
			}
		}
	}
}
