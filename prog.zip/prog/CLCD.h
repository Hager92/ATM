#ifndef CLCD_H_
#define CLCD_H_


#define CLCD_DATA_PORT DIO_PORTA
#define CLCD_CTRL_PORT DIO_PORTC

#define CLCD_RS_PIN DIO_PIN0
#define CLCD_RW_PIN DIO_PIN1
#define CLCD_E_PIN DIO_PIN2


void CLCD_voidSendCommand(u8 Copy_u8Command);
void CLCD_voidSendData(u8 Copy_u8Data);
void CLCD_voidInitl(void);
void CLCD_voidString(const char*Copy_pcSrting);
void CLCD_voidGoTo_X_Y(u8 Copy_u8Xposition,u8 Copy_u8Yposition);
void CLCD_voidLCD_Clear(void);
void CLCD_voidPrintNUM(u32 number);
#endif /* CLCD_H_ */
